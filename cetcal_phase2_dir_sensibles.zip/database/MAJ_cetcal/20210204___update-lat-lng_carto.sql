alter table cetcal_cartographie MODIFY cetcal_prd_lat VARCHAR(64);
alter table cetcal_cartographie MODIFY cetcal_prd_lng VARCHAR(64);