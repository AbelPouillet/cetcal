update cetcal_sondage 
  set reponse = 'D’une formation agricole (BPREA, CAP, BEP, Bac Pro, DEUT...)'
    where clef_question='clef_question' AND
      reponse LIKE '%(BPREA, CAP, BEP, Bac Pro, DEUT%';

update cetcal_information_producteur 
  set information="temps de réflexion partage avec d'autres acteurs : restauration collective, transformateurs, association consommateurs." 
    where information="Temps de réflexion partage avec d&amp";

update cetcal_information_producteur 
  set information="temps de réflexion partage avec d'autres acteurs : restauration collective, transformateurs, association consommateurs." 
    where information="Temps de réflexion partage avec d'autres acteurs : restauration collective, transformateurs, association consommateurs.";
